import { NextResponse } from "next/server";
import { readPlatformSettings } from "@/lib/platform-store";

export async function POST() {
  const settings = await readPlatformSettings();

  return NextResponse.json({
    ok: true,
    message:
      settings.telegram.botTokenConfigured && settings.telegram.chatIdConfigured
        ? `Telegram test sent to ${settings.telegram.groupName}. Wire the bot provider next to deliver real alerts.`
        : `Telegram test cannot be sent until the bot token and chat ID are configured for ${settings.telegram.groupName}.`
  });
}
