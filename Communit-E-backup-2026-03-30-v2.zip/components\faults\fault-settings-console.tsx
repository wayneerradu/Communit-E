"use client";

import { useMemo, useState, useTransition } from "react";
import { faultCategoryOptions, getFaultSubCategoryOptions } from "@/lib/fault-taxonomy";
import type { PlatformSettings } from "@/types/domain";

type Contact = {
  id: string;
  name: string;
  email: string;
  active: boolean;
};

type Props = {
  initialFaultEscalation: PlatformSettings["faultEscalation"];
};

function toId(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function buildSubCategoryList() {
  return faultCategoryOptions.flatMap((category) =>
    getFaultSubCategoryOptions(category.value).map((subCategory) => ({
      optionId: `${category.value}::${subCategory}`,
      key: subCategory,
      label: `${category.label} • ${subCategory}`
    }))
  );
}

function ContactEditor({
  title,
  contacts,
  onChange
}: {
  title: string;
  contacts: Contact[];
  onChange: (next: Contact[]) => void;
}) {
  function updateRow(id: string, field: keyof Contact, value: string | boolean) {
    onChange(
      contacts.map((contact) =>
        contact.id === id
          ? {
              ...contact,
              [field]: value
            }
          : contact
      )
    );
  }

  function removeRow(id: string) {
    onChange(contacts.filter((contact) => contact.id !== id));
  }

  function addRow() {
    onChange([...contacts, { id: toId("fault-contact"), name: "", email: "", active: true }]);
  }

  return (
    <article className="surface-panel">
      <div className="section-header">
        <div>
          <h2>{title}</h2>
          <p>Keep this list current so escalation emails always target the correct people.</p>
        </div>
        <button type="button" className="button-secondary" onClick={addRow}>
          Add Contact
        </button>
      </div>

      <div className="dashboard-stack">
        {contacts.length === 0 ? (
          <article className="dashboard-today-card">
            <strong>No contacts added yet.</strong>
            <p>Add one or more contacts to activate this escalation group.</p>
          </article>
        ) : (
          contacts.map((contact) => (
            <article key={contact.id} className="dashboard-queue-card">
              <div className="form-grid">
                <label className="field">
                  <span>Full Name</span>
                  <input
                    value={contact.name}
                    onChange={(event) => updateRow(contact.id, "name", event.target.value)}
                    placeholder="Name and surname"
                  />
                </label>
                <label className="field">
                  <span>Email Address</span>
                  <input
                    value={contact.email}
                    onChange={(event) => updateRow(contact.id, "email", event.target.value)}
                    placeholder="name@department.gov.za"
                  />
                </label>
                <label className="toggle-field">
                  <input
                    type="checkbox"
                    checked={contact.active}
                    onChange={(event) => updateRow(contact.id, "active", event.target.checked)}
                  />
                  <span>Active</span>
                </label>
              </div>
              <div className="action-row">
                <button type="button" className="button-secondary" onClick={() => removeRow(contact.id)}>
                  Remove
                </button>
              </div>
            </article>
          ))
        )}
      </div>
    </article>
  );
}

export function FaultSettingsConsole({ initialFaultEscalation }: Props) {
  const [isPending, startTransition] = useTransition();
  const [message, setMessage] = useState<string | null>(null);
  const [tone, setTone] = useState<"success" | "warning">("success");
  const [initialContacts, setInitialContacts] = useState<Contact[]>(
    initialFaultEscalation.initialContacts.map((contact) => ({ ...contact }))
  );
  const [plusBySubCategory, setPlusBySubCategory] = useState<Record<string, Contact[]>>(
    initialFaultEscalation.escalatePlusBySubCategory
  );
  const [plusPlusBySubCategory, setPlusPlusBySubCategory] = useState<Record<string, Contact[]>>(
    initialFaultEscalation.escalatePlusPlusBySubCategory
  );

  const allSubCategories = useMemo(buildSubCategoryList, []);
  const [selectedSubCategory, setSelectedSubCategory] = useState<string>(allSubCategories[0]?.key ?? "");

  const selectedPlusContacts = plusBySubCategory[selectedSubCategory] ?? [];
  const selectedPlusPlusContacts = plusPlusBySubCategory[selectedSubCategory] ?? [];

  function setSelectedPlusContacts(next: Contact[]) {
    setPlusBySubCategory((current) => ({ ...current, [selectedSubCategory]: next }));
  }

  function setSelectedPlusPlusContacts(next: Contact[]) {
    setPlusPlusBySubCategory((current) => ({ ...current, [selectedSubCategory]: next }));
  }

  function saveSettings() {
    startTransition(() => {
      void (async () => {
        try {
          const response = await fetch("/api/super-admin/settings", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              faultEscalation: {
                initialContacts,
                escalatePlusBySubCategory: plusBySubCategory,
                escalatePlusPlusBySubCategory: plusPlusBySubCategory
              }
            })
          });
          const payload = await response.json();
          if (!response.ok) {
            throw new Error(payload.error ?? "Unable to save fault escalation settings.");
          }
          setTone("success");
          setMessage("Fault escalation settings saved.");
        } catch (error) {
          setTone("warning");
          setMessage(error instanceof Error ? error.message : "Unable to save fault escalation settings.");
        }
      })();
    });
  }

  return (
    <>
      {message ? (
        <section className={`flash-panel flash-panel-${tone}`}>
          <strong>{message}</strong>
        </section>
      ) : null}

      <section className="dashboard-feature-grid">
        <ContactEditor title="Escalation Level 1 Contacts" contacts={initialContacts} onChange={setInitialContacts} />
      </section>

      <section className="surface-panel clean-marine-panel">
        <div className="section-header">
          <div>
            <h2>Escalate+ And Escalate++ Contacts By Subcategory</h2>
            <p>Select a subcategory and maintain both escalation groups as people change.</p>
          </div>
          <label className="field">
            <span>Fault Subcategory</span>
            <select
              className="native-select"
              value={selectedSubCategory}
              onChange={(event) => setSelectedSubCategory(event.target.value)}
            >
              {allSubCategories.map((item) => (
                <option key={item.optionId} value={item.key}>
                  {item.label}
                </option>
              ))}
            </select>
          </label>
        </div>
      </section>

      <section className="dashboard-feature-grid">
        <ContactEditor title="Escalate+ Contacts" contacts={selectedPlusContacts} onChange={setSelectedPlusContacts} />
        <ContactEditor
          title="Escalate++ Contacts"
          contacts={selectedPlusPlusContacts}
          onChange={setSelectedPlusPlusContacts}
        />
      </section>

      <section className="surface-panel clean-marine-panel">
        <div className="action-row">
          <button type="button" className="button-primary" onClick={saveSettings} disabled={isPending}>
            {isPending ? "Saving..." : "Save Fault Settings"}
          </button>
        </div>
      </section>
    </>
  );
}
