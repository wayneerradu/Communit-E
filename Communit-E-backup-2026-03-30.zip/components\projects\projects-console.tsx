"use client";

import { useEffect, useMemo, useState } from "react";
import { GlobalSearch } from "@/components/shared/global-search";
import { UserBadge } from "@/components/shared/user-badge";
import type { GlobalSearchItem, ParkingLotIdea, Project, ProjectTask, SessionUser } from "@/types/domain";

type ProjectsConsoleProps = {
  initialProjects: Project[];
  parkingLotIdeas: ParkingLotIdea[];
  currentUser: SessionUser | null;
  focusProjectId?: string;
  focusQueue?: string;
  focusAction?: string;
  contextMessage?: string;
};

const projectFormDefaults = {
  title: "",
  description: ""
};

const taskFormDefaults = {
  title: "",
  assignee: "",
  dueDate: "",
  status: "todo" as ProjectTask["status"]
};

const laneOrder: Array<{ title: string; status: ProjectTask["status"] }> = [
  { title: "Not Started", status: "todo" },
  { title: "Started", status: "started" },
  { title: "In Progress", status: "in-progress" },
  { title: "Stuck", status: "blocked" },
  { title: "Complete", status: "done" }
];

export function ProjectsConsole({
  initialProjects,
  parkingLotIdeas,
  currentUser,
  focusProjectId,
  focusQueue,
  focusAction,
  contextMessage
}: ProjectsConsoleProps) {
  const [projects, setProjects] = useState(initialProjects);
  const [selectedProjectId, setSelectedProjectId] = useState(initialProjects[0]?.id ?? "");
  const [projectForm, setProjectForm] = useState(projectFormDefaults);
  const [taskForm, setTaskForm] = useState(taskFormDefaults);
  const [message, setMessage] = useState<string | null>(null);
  const [isBusy, setIsBusy] = useState(false);
  const blockedProject = projects.find((project) => project.tasks.some((task) => task.status === "blocked"));

  const featuredProject = projects.find((project) => project.id === selectedProjectId) ?? projects[0];
  const tasks = featuredProject?.tasks ?? [];
  const kanbanColumns = useMemo(
    () =>
      laneOrder.map((lane) => ({
        ...lane,
        tasks: tasks.filter((task) => task.status === lane.status)
      })),
    [tasks]
  );
  const highlightedTaskId =
    focusQueue === "blocked"
      ? tasks.find((task) => task.status === "blocked")?.id
      : undefined;
  const jumpTargetId = highlightedTaskId ? `project-task-focus-${highlightedTaskId}` : "project-task-actions";
  const searchItems: GlobalSearchItem[] = projects.map((project) => ({
    id: project.id,
    title: project.title,
    subtitle: [project.status, project.description].filter(Boolean).join(" • "),
    kind: "project",
    keywords: project.tasks.map((task) => [task.title, task.assignee, task.status].filter(Boolean).join(" ")).filter(Boolean)
  }));

  useEffect(() => {
    if (focusProjectId && projects.some((project) => project.id === focusProjectId)) {
      setSelectedProjectId(focusProjectId);
      return;
    }

    if (focusQueue === "blocked" && blockedProject) {
      setSelectedProjectId(blockedProject.id);
    }
  }, [blockedProject, focusProjectId, focusQueue, projects]);

  useEffect(() => {
    if (!contextMessage) return;
    const timer = window.setTimeout(() => {
      document.getElementById(jumpTargetId)?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 180);
    return () => window.clearTimeout(timer);
  }, [contextMessage, jumpTargetId]);

  async function createProjectAction() {
    setIsBusy(true);
    setMessage(null);

    try {
      const response = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(projectForm)
      });
      const payload = await response.json();
      if (!response.ok) {
        throw new Error(payload.error ?? "Unable to create project.");
      }

      setProjects((current) => [payload.item, ...current]);
      setSelectedProjectId(payload.item.id);
      setProjectForm(projectFormDefaults);
      setMessage("Project created.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Unable to create project.");
    } finally {
      setIsBusy(false);
    }
  }

  async function addTaskAction() {
    if (!featuredProject) return;
    setIsBusy(true);
    setMessage(null);

    try {
      const response = await fetch(`/api/projects/${featuredProject.id}/tasks`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(taskForm)
      });
      const payload = await response.json();
      if (!response.ok) {
        throw new Error(payload.error ?? "Unable to add task.");
      }

      setProjects((current) =>
        current.map((project) =>
          project.id === featuredProject.id ? { ...project, tasks: [payload.item, ...project.tasks] } : project
        )
      );
      setTaskForm(taskFormDefaults);
      setMessage("Task added to project.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Unable to add task.");
    } finally {
      setIsBusy(false);
    }
  }

  async function moveTask(task: ProjectTask, status: ProjectTask["status"]) {
    if (!featuredProject || task.status === status) return;
    setIsBusy(true);
    setMessage(null);

    try {
      const response = await fetch(`/api/projects/${featuredProject.id}/tasks/${task.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status })
      });
      const payload = await response.json();
      if (!response.ok) {
        throw new Error(payload.error ?? "Unable to move task.");
      }

      setProjects((current) =>
        current.map((project) =>
          project.id === featuredProject.id
            ? {
                ...project,
                tasks: project.tasks.map((item) => (item.id === task.id ? { ...item, status: payload.task.status } : item))
              }
            : project
        )
      );
      setMessage(`Task moved to ${status}.`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Unable to move task.");
    } finally {
      setIsBusy(false);
    }
  }

  function jumpToSection(sectionId: string) {
    window.setTimeout(() => {
      document.getElementById(sectionId)?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 80);
  }

  function handleStatTileClick(target: "projects" | "tasks" | "stuck" | "parking") {
    if (target === "projects" && projects[0]) {
      setSelectedProjectId(projects[0].id);
      jumpToSection("projects-board");
      return;
    }

    if (target === "tasks") {
      jumpToSection("projects-task-intake");
      return;
    }

    if (target === "stuck" && blockedProject) {
      setSelectedProjectId(blockedProject.id);
      jumpToSection("projects-board");
      return;
    }

    jumpToSection("projects-parking-linkage");
  }

  return (
    <>
      <header className="page-header">
        <div>
          <h1>Projects Hub</h1>
          <p>Track long-term work that is not a fault, keep tasks moving, surface blockers quickly, and help each other finish what matters.</p>
        </div>
        <div className="dashboard-actions">
          <GlobalSearch
            items={searchItems}
            onItemSelect={(item) => {
              setSelectedProjectId(item.id);
              jumpToSection("projects-board");
            }}
          />
          <button className="button-primary" type="button" onClick={createProjectAction} disabled={isBusy}>
            {isBusy ? "Working..." : "New Project"}
          </button>
        </div>
      </header>

      {message ? (
        <section className="flash-panel flash-panel-success">
          <strong>{message}</strong>
        </section>
      ) : null}

      {contextMessage ? (
        <section className="flash-panel flash-panel-default dashboard-context-banner dashboard-context-banner-sticky">
          <div className="panel-head">
            <strong>Opened from Admin Dashboard</strong>
            <button className="button-secondary" type="button" onClick={() => document.getElementById(jumpTargetId)?.scrollIntoView({ behavior: "smooth", block: "center" })}>
              Jump to item
            </button>
          </div>
          <p>{contextMessage}</p>
          {focusAction ? <span className="tag">Next action: {focusAction}</span> : null}
        </section>
      ) : null}

      <section className="dashboard-stat-grid">
        <button type="button" className="dashboard-stat-card dashboard-stat-card-success dashboard-stat-button dashboard-card-link" onClick={() => handleStatTileClick("projects")}>
          <span>Active Projects</span>
          <strong>{projects.length}</strong>
          <small>Live collaborative initiatives</small>
        </button>
        <button type="button" className="dashboard-stat-card dashboard-stat-card-warning dashboard-stat-button dashboard-card-link" onClick={() => handleStatTileClick("tasks")}>
          <span>Open Tasks</span>
          <strong>{tasks.length}</strong>
          <small>Across the current project</small>
        </button>
        <button type="button" className="dashboard-stat-card dashboard-stat-card-danger dashboard-stat-button dashboard-card-link" onClick={() => handleStatTileClick("stuck")}>
          <span>Stuck</span>
          <strong>{tasks.filter((task) => task.status === "blocked").length}</strong>
          <small>Needs support and follow-up</small>
        </button>
        <button type="button" className="dashboard-stat-card dashboard-stat-card-default dashboard-stat-button dashboard-card-link" onClick={() => handleStatTileClick("parking")}>
          <span>Parking Lot Ready</span>
          <strong>{parkingLotIdeas.length}</strong>
          <small>Ideas waiting for action</small>
        </button>
      </section>

      <section className="dashboard-feature-grid">
        <article className="surface-panel clean-marine-panel">
          <div className="section-header">
            <div>
              <h2>Project Intake</h2>
              <p>Keep project setup lightweight so the team can capture an initiative quickly and start moving tasks.</p>
            </div>
            <span className="status-chip status-chip-success">Live Form</span>
          </div>

          <div className="form-grid">
            <label className="field field-wide">
              <span>Project Name</span>
              <input value={projectForm.title} onChange={(event) => setProjectForm((current) => ({ ...current, title: event.target.value }))} />
            </label>
            <label className="field field-full">
              <span>Description</span>
              <textarea value={projectForm.description} onChange={(event) => setProjectForm((current) => ({ ...current, description: event.target.value }))} rows={3} />
            </label>
          </div>

          <div className="dashboard-actions-row">
            {projects.map((project) => (
              <button
                key={project.id}
                type="button"
                className={`faults-selection-pill${project.id === featuredProject?.id ? " faults-selection-pill-active" : ""}`}
                onClick={() => setSelectedProjectId(project.id)}
              >
                {project.title}
              </button>
            ))}
          </div>
        </article>

        <article id="projects-task-intake" className="surface-panel clean-marine-panel">
          <div className="section-header">
            <div>
              <h2>Task Intake</h2>
              <p>Add tasks directly into the selected project so the Kanban board stays current without admin overhead.</p>
            </div>
            <span className="status-chip status-chip-warning">Task Flow</span>
          </div>

          <div className="form-grid">
            <label className="field field-wide">
              <span>Task Title</span>
              <input value={taskForm.title} onChange={(event) => setTaskForm((current) => ({ ...current, title: event.target.value }))} />
            </label>
            <label className="field field-wide">
              <span>Owner</span>
              <input value={taskForm.assignee} onChange={(event) => setTaskForm((current) => ({ ...current, assignee: event.target.value }))} />
            </label>
            <label className="field field-wide">
              <span>Due Date</span>
              <input type="date" value={taskForm.dueDate} onChange={(event) => setTaskForm((current) => ({ ...current, dueDate: event.target.value }))} />
            </label>
            <label className="field field-wide">
              <span>Lane</span>
              <select value={taskForm.status} onChange={(event) => setTaskForm((current) => ({ ...current, status: event.target.value as ProjectTask["status"] }))}>
                {laneOrder.map((lane) => (
                  <option key={lane.status} value={lane.status}>
                    {lane.title}
                  </option>
                ))}
              </select>
            </label>
          </div>

          <div className="dashboard-actions-row">
            <button className="button-primary" type="button" onClick={addTaskAction} disabled={isBusy || !featuredProject}>
              Add Task
            </button>
          </div>
        </article>
      </section>

      <section className="dashboard-feature-grid">
        <article id="projects-board" className="surface-panel clean-marine-panel">
          <div className="section-header">
            <div>
              <h2>{featuredProject?.title ?? "Projects Board"}</h2>
              <p>Use a light Kanban board so everyone can see momentum, blockers, and where help is needed without formal project overhead.</p>
            </div>
            <span className="status-chip status-chip-success">{featuredProject?.status ?? "planned"}</span>
          </div>

          <div className="projects-kanban-grid">
            {kanbanColumns.map((column) => (
              <article key={column.title} className="projects-kanban-column">
                <div className="panel-head">
                  <strong>{column.title}</strong>
                  <span className="status-chip status-chip-default">{column.tasks.length}</span>
                </div>
                <div className="dashboard-stack">
                  {column.tasks.map((task) => (
                    <article key={task.id} id={`project-task-focus-${task.id}`} className={`projects-task-card${highlightedTaskId === task.id ? " dashboard-context-highlight" : ""}`}>
                      <strong>{task.title}</strong>
                      {task.assignee ? <UserBadge name={task.assignee} currentUser={currentUser} compact /> : <p>Owner not set yet</p>}
                      <div className="meta-row">
                        <span className="tag">{task.dueDate ?? "No due date"}</span>
                      </div>
                      <div id={highlightedTaskId === task.id ? "project-task-actions" : undefined} className="projects-task-actions">
                        {laneOrder
                          .filter((lane) => lane.status !== task.status)
                          .slice(0, 2)
                          .map((lane) => (
                            <button key={lane.status} type="button" className={`button-secondary${highlightedTaskId === task.id && focusAction === "update" ? " dashboard-action-highlight-secondary" : ""}`} onClick={() => moveTask(task, lane.status)} disabled={isBusy}>
                              {lane.title}
                            </button>
                          ))}
                      </div>
                    </article>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </article>

        <article id="projects-parking-linkage" className="surface-panel clean-marine-panel">
          <div className="section-header">
            <div>
              <h2>Parking Lot Linkage</h2>
              <p>Ideas stay visible here until they become projects, resolutions, or stay parked for later.</p>
            </div>
            <span className="status-chip status-chip-default">Idea Flow</span>
          </div>

          <div className="dashboard-stack">
            {parkingLotIdeas.slice(0, 3).map((idea) => (
              <article key={idea.id} className="dashboard-approval-card">
                <div className="panel-head">
                  <div>
                    <h3>{idea.title}</h3>
                    <p>{idea.justification}</p>
                  </div>
                  <span className={`status-chip status-chip-${idea.priority === "high" ? "warning" : "default"}`}>{idea.status}</span>
                </div>
                <div className="meta-row">
                  <span className="tag">Priority: {idea.priority}</span>
                  <span className="tag">Votes: {idea.votes.length}</span>
                  <span className="tag">Threshold: {idea.threshold}</span>
                </div>
              </article>
            ))}
          </div>
        </article>
      </section>
    </>
  );
}
