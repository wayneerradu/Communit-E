import { FaultsSubpageConsole } from "@/components/faults/faults-subpage-console";
import { getFaultsData } from "@/lib/hub-data";

export default function ClosedFaultsPage() {
  const { faults } = getFaultsData();
  const closedFaults = faults.filter((fault) => fault.status === "closed" || fault.status === "archived");

  return (
    <FaultsSubpageConsole
      title="Closed Faults"
      description="Searchable history of resolved and archived faults so the team can prove action and learn from closure patterns."
      faults={closedFaults}
      badgeLabel={`${closedFaults.length} closed`}
      emptyTitle="No closed faults yet."
      emptyDetail="Resolved and archived faults will appear here once the live workflow has more history."
      searchPlaceholder="Search resolved roads, categories, or closed faults..."
    />
  );
}
