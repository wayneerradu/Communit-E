import { NextResponse } from "next/server";
import { updateProjectTaskStatus } from "@/lib/workflows";

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string; taskId: string }> }
) {
  const { id, taskId } = await params;
  const payload = await request.json();
  const result = updateProjectTaskStatus(id, taskId, payload.status);
  return NextResponse.json(result);
}
