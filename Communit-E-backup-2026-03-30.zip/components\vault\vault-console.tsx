"use client";

import { useState } from "react";
import { GlobalSearch } from "@/components/shared/global-search";
import type { GlobalSearchItem, VaultAsset } from "@/types/domain";

type VaultConsoleProps = {
  initialAssets: VaultAsset[];
};

const defaultForm = {
  assetName: "",
  filePath: "",
  category: "Template",
  description: "",
  visibility: "all" as VaultAsset["visibility"]
};

export function VaultConsole({ initialAssets }: VaultConsoleProps) {
  const [assets, setAssets] = useState(initialAssets);
  const [form, setForm] = useState(defaultForm);
  const [message, setMessage] = useState<string | null>(null);
  const [isBusy, setIsBusy] = useState(false);
  const searchItems: GlobalSearchItem[] = assets.map((asset) => ({
    id: asset.id,
    title: asset.assetName,
    subtitle: [asset.category, asset.visibility].join(" • "),
    kind: "vault",
    keywords: [asset.description, asset.filePath].filter(Boolean)
  }));

  async function addAsset() {
    setIsBusy(true);
    setMessage(null);

    try {
      const response = await fetch("/api/vault", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const payload = await response.json();
      if (!response.ok) {
        throw new Error(payload.error ?? "Unable to add vault item.");
      }

      setAssets((current) => [payload.item, ...current]);
      setForm(defaultForm);
      setMessage("Vault item added.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Unable to add vault item.");
    } finally {
      setIsBusy(false);
    }
  }

  return (
    <>
      <header className="page-header">
        <div>
          <h1>Vault</h1>
          <p>Central templates, documents, media, and important links in one clean internal resource center.</p>
        </div>
        <div className="dashboard-actions">
          <GlobalSearch
            items={searchItems}
            onItemSelect={(item) => {
              window.setTimeout(() => {
                document.getElementById(`vault-focus-${item.id}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
              }, 80);
            }}
          />
          <button className="button-primary" type="button" onClick={addAsset} disabled={isBusy}>
            {isBusy ? "Working..." : "Add Vault Item"}
          </button>
        </div>
      </header>

      {message ? (
        <section className="flash-panel flash-panel-success">
          <strong>{message}</strong>
        </section>
      ) : null}

      <section className="dashboard-feature-grid">
        <article className="surface-panel clean-marine-panel">
          <div className="section-header">
            <div>
              <h2>Vault Intake</h2>
              <p>Add a document, template, media asset, or important link so the team keeps using the same approved resources.</p>
            </div>
            <span className="status-chip status-chip-success">Live Intake</span>
          </div>

          <div className="form-grid">
            <label className="field field-wide">
              <span>Asset Name</span>
              <input value={form.assetName} onChange={(event) => setForm((current) => ({ ...current, assetName: event.target.value }))} />
            </label>
            <label className="field field-wide">
              <span>File Path / URL</span>
              <input value={form.filePath} onChange={(event) => setForm((current) => ({ ...current, filePath: event.target.value }))} />
            </label>
            <label className="field field-wide">
              <span>Category</span>
              <select value={form.category} onChange={(event) => setForm((current) => ({ ...current, category: event.target.value }))}>
                <option value="Template">Template</option>
                <option value="Document">Document</option>
                <option value="Brand">Brand</option>
                <option value="Resolution">Resolution</option>
                <option value="Media">Media</option>
                <option value="Important Link">Important Link</option>
              </select>
            </label>
            <label className="field field-wide">
              <span>Visibility</span>
              <select value={form.visibility} onChange={(event) => setForm((current) => ({ ...current, visibility: event.target.value as VaultAsset["visibility"] }))}>
                <option value="all">All</option>
                <option value="admin">Admin</option>
                <option value="pro">PRO</option>
              </select>
            </label>
            <label className="field field-full">
              <span>Description</span>
              <textarea value={form.description} onChange={(event) => setForm((current) => ({ ...current, description: event.target.value }))} rows={4} />
            </label>
          </div>
        </article>

        <article className="surface-panel clean-marine-panel">
          <div className="section-header">
            <div>
              <h2>Available Assets</h2>
              <p>Templates, documents, media, and links stay visible and reusable across the app.</p>
            </div>
            <span className="status-chip status-chip-default">{assets.length} items</span>
          </div>

          <div className="dashboard-stack">
            {assets.map((asset) => (
              <article key={asset.id} id={`vault-focus-${asset.id}`} className="dashboard-minute-card">
                <div className="panel-head">
                  <strong>{asset.assetName}</strong>
                  <span className="status-chip status-chip-default">{asset.category}</span>
                </div>
                <p>{asset.description}</p>
                <div className="meta-row">
                  <span className="tag">{asset.visibility}</span>
                  <span className="tag vault-path-tag">{asset.filePath}</span>
                </div>
              </article>
            ))}
          </div>
        </article>
      </section>
    </>
  );
}
