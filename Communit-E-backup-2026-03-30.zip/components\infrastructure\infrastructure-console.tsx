﻿"use client";

import { useMemo, useState } from "react";
import { GlobalSearch } from "@/components/shared/global-search";
import { UserBadge } from "@/components/shared/user-badge";
import type { Fault, GlobalSearchItem, InfrastructureAsset, SessionUser } from "@/types/domain";

type InfrastructureConsoleProps = {
  initialAssets: InfrastructureAsset[];
  faults: Fault[];
  currentUser: SessionUser | null;
};

const defaultForm = {
  assetName: "",
  assetType: "streetlight-pole" as InfrastructureAsset["assetType"],
  condition: "",
  street: "",
  latitude: "",
  longitude: "",
  notes: ""
};

function getAssetTone(assetType: string) {
  switch (assetType) {
    case "streetlight-pole":
    case "optic-fiber-pole":
    case "water-meter":
      return "default";
    case "water-valve":
    case "fire-hydrant":
    case "manhole":
      return "warning";
    case "electrical-substation":
    case "electrical-distribution-box":
    case "traffic-light":
      return "danger";
    default:
      return "success";
  }
}

export function InfrastructureConsole({ initialAssets, faults, currentUser }: InfrastructureConsoleProps) {
  const [assets, setAssets] = useState(initialAssets);
  const [selectedAssetId, setSelectedAssetId] = useState(initialAssets[0]?.id ?? "");
  const [form, setForm] = useState(defaultForm);
  const [noteDraft, setNoteDraft] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [isBusy, setIsBusy] = useState(false);

  const featuredAsset = assets.find((asset) => asset.id === selectedAssetId) ?? assets[0];
  const linkedFaults = useMemo(
    () =>
      faults.filter((fault) =>
        featuredAsset ? fault.locationText.toLowerCase().includes(featuredAsset.street.toLowerCase()) : false
      ),
    [faults, featuredAsset]
  );

  const queues = [
    { label: "Missing official refs", value: "4", tone: "warning" },
    { label: "Needs GPS correction", value: "2", tone: "default" },
    { label: "Needs photo", value: "3", tone: "warning" },
    { label: "Duplicate suspected", value: "1", tone: "danger" }
  ];
  const searchItems: GlobalSearchItem[] = assets.map((asset) => ({
    id: asset.id,
    title: asset.assetName,
    subtitle: [asset.street, asset.assetType, asset.condition].filter(Boolean).join(" • "),
    kind: "infrastructure",
    keywords: [asset.notes].filter(Boolean) as string[]
  }));

  async function createAsset() {
    setIsBusy(true);
    setMessage(null);

    try {
      const response = await fetch("/api/infrastructure", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const payload = await response.json();
      if (!response.ok) {
        throw new Error(payload.error ?? "Unable to add asset.");
      }

      setAssets((current) => [payload.item, ...current]);
      setSelectedAssetId(payload.item.id);
      setForm(defaultForm);
      setMessage("Infrastructure asset added.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Unable to add asset.");
    } finally {
      setIsBusy(false);
    }
  }

  async function updateAsset() {
    if (!featuredAsset || !noteDraft.trim()) return;
    if (noteDraft.trim() === (featuredAsset.notes ?? "").trim()) {
      setMessage("No changes to save.");
      return;
    }
    setIsBusy(true);
    setMessage(null);

    try {
      const response = await fetch(`/api/infrastructure/${featuredAsset.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ notes: noteDraft, condition: featuredAsset.condition })
      });
      const payload = await response.json();
      if (!response.ok) {
        throw new Error(payload.error ?? "Unable to update asset.");
      }

      setAssets((current) => current.map((asset) => (asset.id === payload.item.id ? payload.item : asset)));
      setNoteDraft("");
      setMessage("Asset notes updated.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Unable to update asset.");
    } finally {
      setIsBusy(false);
    }
  }

  async function updateCondition(condition: string) {
    if (!featuredAsset) return;
    if (condition === featuredAsset.condition) {
      setMessage("No changes to save.");
      return;
    }
    setIsBusy(true);
    setMessage(null);

    try {
      const response = await fetch(`/api/infrastructure/${featuredAsset.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ condition })
      });
      const payload = await response.json();
      if (!response.ok) {
        throw new Error(payload.error ?? "Unable to update condition.");
      }

      setAssets((current) => current.map((asset) => (asset.id === payload.item.id ? payload.item : asset)));
      setMessage(`Condition updated to ${condition}.`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Unable to update condition.");
    } finally {
      setIsBusy(false);
    }
  }

  function jumpToSection(sectionId: string) {
    window.setTimeout(() => {
      document.getElementById(sectionId)?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 80);
  }

  function handleStatTileClick(target: "assets" | "review" | "linked" | "repeated") {
    if (target === "assets" && assets[0]) {
      setSelectedAssetId(assets[0].id);
      jumpToSection("infrastructure-asset-snapshot");
      return;
    }

    if (target === "linked" && linkedFaults[0]) {
      jumpToSection("infrastructure-fault-linkage");
      return;
    }

    if (target === "review" || target === "repeated") {
      if (featuredAsset) {
        setSelectedAssetId(featuredAsset.id);
      }
      jumpToSection("infrastructure-asset-snapshot");
    }
  }

  return (
    <>
      <header className="page-header">
        <div>
          <h1>Infrastructure Hub</h1>
          <p>Track poles, manholes, fiber, and other mapped assets with photos, verification state, and quick fault logging built in.</p>
        </div>
        <div className="dashboard-actions">
          <GlobalSearch
            items={searchItems}
            onItemSelect={(item) => {
              setSelectedAssetId(item.id);
              jumpToSection("infrastructure-asset-snapshot");
            }}
          />
          <button className="button-primary" type="button" onClick={createAsset} disabled={isBusy}>
            {isBusy ? "Working..." : "Add Asset"}
          </button>
        </div>
      </header>

      {message ? (
        <section className="flash-panel flash-panel-success">
          <strong>{message}</strong>
        </section>
      ) : null}

      <section className="dashboard-stat-grid">
        <button type="button" className="dashboard-stat-card dashboard-stat-card-default dashboard-stat-button dashboard-card-link" onClick={() => handleStatTileClick("assets")}>
          <span>Mapped Assets</span>
          <strong>{assets.length}</strong>
          <small>Internal asset register</small>
        </button>
        <button type="button" className="dashboard-stat-card dashboard-stat-card-warning dashboard-stat-button dashboard-card-link" onClick={() => handleStatTileClick("review")}>
          <span>Needs Review</span>
          <strong>{queues.reduce((total, queue) => total + Number(queue.value), 0)}</strong>
          <small>Data quality and verification</small>
        </button>
        <button type="button" className="dashboard-stat-card dashboard-stat-card-success dashboard-stat-button dashboard-card-link" onClick={() => handleStatTileClick("linked")}>
          <span>Linked Faults</span>
          <strong>{linkedFaults.length}</strong>
          <small>Operational context attached</small>
        </button>
        <button type="button" className="dashboard-stat-card dashboard-stat-card-danger dashboard-stat-button dashboard-card-link" onClick={() => handleStatTileClick("repeated")}>
          <span>Repeated Failures</span>
          <strong>{Math.max(linkedFaults.length - 1, 0)}</strong>
          <small>Hotspot indicators</small>
        </button>
      </section>

      <section className="dashboard-feature-grid">
        <article id="infrastructure-asset-snapshot" className="surface-panel clean-marine-panel">
          <div className="section-header">
            <div>
              <h2>Asset Intake</h2>
              <p>Add an asset quickly now and improve the record over time as GPS, photos, and official references become available.</p>
            </div>
            <span className="status-chip status-chip-success">Live Intake</span>
          </div>

          <div className="form-grid">
            <label className="field field-wide">
              <span>Asset Name</span>
              <input value={form.assetName} onChange={(event) => setForm((current) => ({ ...current, assetName: event.target.value }))} />
            </label>
            <label className="field field-wide">
              <span>Type</span>
              <select value={form.assetType} onChange={(event) => setForm((current) => ({ ...current, assetType: event.target.value as InfrastructureAsset["assetType"] }))}>
                <option value="streetlight-pole">Streetlight Pole</option>
                <option value="optic-fiber-pole">Optic Fiber Pole</option>
                <option value="electrical-substation">Electrical Substation</option>
                <option value="electrical-distribution-box">Electrical Distribution Box</option>
                <option value="water-meter">Water Meter</option>
                <option value="water-valve">Water Valve</option>
                <option value="fire-hydrant">Fire Hydrant</option>
                <option value="traffic-light">Traffic Light</option>
                <option value="manhole">Manhole</option>
              </select>
            </label>
            <label className="field field-wide">
              <span>Condition</span>
              <input value={form.condition} onChange={(event) => setForm((current) => ({ ...current, condition: event.target.value }))} />
            </label>
            <label className="field field-wide">
              <span>Road</span>
              <input value={form.street} onChange={(event) => setForm((current) => ({ ...current, street: event.target.value }))} />
            </label>
            <label className="field field-wide">
              <span>Latitude</span>
              <input value={form.latitude} onChange={(event) => setForm((current) => ({ ...current, latitude: event.target.value }))} />
            </label>
            <label className="field field-wide">
              <span>Longitude</span>
              <input value={form.longitude} onChange={(event) => setForm((current) => ({ ...current, longitude: event.target.value }))} />
            </label>
            <label className="field field-full">
              <span>Notes</span>
              <textarea value={form.notes} onChange={(event) => setForm((current) => ({ ...current, notes: event.target.value }))} rows={4} />
            </label>
          </div>
        </article>

        <article id="infrastructure-fault-linkage" className="surface-panel clean-marine-panel">
          <div className="section-header">
            <div>
              <h2>Layered Asset Map</h2>
              <p>Different infrastructure types remain readable on one map so admins can find the right asset without walking the road first.</p>
            </div>
            <span className="status-chip status-chip-success">Map Ready</span>
          </div>

          <div className="infrastructure-map-surface">
            <div className="infrastructure-map-road infrastructure-map-road-one" />
            <div className="infrastructure-map-road infrastructure-map-road-two" />
            <div className="infrastructure-map-pin infrastructure-map-pin-default infrastructure-map-pin-a" />
            <div className="infrastructure-map-pin infrastructure-map-pin-warning infrastructure-map-pin-b" />
            <div className="infrastructure-map-pin infrastructure-map-pin-success infrastructure-map-pin-c" />
            <div className="infrastructure-map-pin infrastructure-map-pin-danger infrastructure-map-pin-d" />
            <div className="infrastructure-map-pin infrastructure-map-pin-default infrastructure-map-pin-e" />
            <div>
              <strong>Mount Vernon asset layer</strong>
              <p>Select an asset from the register below to work the details and linked fault context.</p>
            </div>
          </div>
        </article>
      </section>

      <section className="dashboard-feature-grid">
        <article className="surface-panel clean-marine-panel">
          <div className="section-header">
            <div>
              <h2>Asset Snapshot</h2>
              <p>Operational context without forcing admins into a heavy GIS workflow.</p>
            </div>
            {featuredAsset ? <span className={`status-chip status-chip-${getAssetTone(featuredAsset.assetType)}`}>{featuredAsset.assetType}</span> : null}
          </div>

          {featuredAsset ? (
            <>
              <div className="dashboard-actions-row">
                {assets.map((asset) => (
                  <button
                    key={asset.id}
                    type="button"
                    className={`faults-selection-pill${asset.id === featuredAsset.id ? " faults-selection-pill-active" : ""}`}
                    onClick={() => setSelectedAssetId(asset.id)}
                  >
                    {asset.assetName}
                  </button>
                ))}
              </div>

              <div className="field-grid">
                <div className="field">
                  <label>CommUNIT-E Asset ID</label>
                  <strong>{featuredAsset.id}</strong>
                </div>
                <div className="field">
                  <label>Official Reference</label>
                  <strong>Pending</strong>
                </div>
                <div className="field">
                  <label>Asset Name</label>
                  <strong>{featuredAsset.assetName}</strong>
                </div>
                <div className="field">
                  <label>Condition</label>
                  <strong>{featuredAsset.condition}</strong>
                </div>
                <div className="field">
                  <label>Road</label>
                  <strong>{featuredAsset.street}</strong>
                </div>
                <div className="field">
                  <label>Linked Faults</label>
                  <strong>{linkedFaults.length}</strong>
                </div>
              </div>

              <div className="dashboard-actions-row">
                <button className="button-secondary" type="button" onClick={() => updateCondition("Verified and active")} disabled={isBusy}>
                  Mark Verified
                </button>
                <button className="button-secondary" type="button" onClick={() => updateCondition("Needs field review")} disabled={isBusy}>
                  Needs Review
                </button>
                <button className="button-primary" type="button" disabled>
                  Create Fault
                </button>
              </div>

              <div className="fault-note-composer">
                <label className="field field-full">
                  <span>Asset Notes</span>
                  <textarea value={noteDraft} onChange={(event) => setNoteDraft(event.target.value)} rows={4} placeholder={featuredAsset.notes ?? "Add field intelligence, GPS corrections, or verification notes..."} />
                </label>
                <div className="dashboard-actions-row">
                  <button className="button-primary" type="button" onClick={updateAsset} disabled={isBusy || !noteDraft.trim()}>
                    Save Notes
                  </button>
                </div>
              </div>
            </>
          ) : null}
        </article>

        <article className="surface-panel clean-marine-panel">
          <div className="section-header">
            <div>
              <h2>Fault Linkage</h2>
              <p>Assets become operationally useful when they show repeated failures and recent incident history.</p>
            </div>
            <span className="status-chip status-chip-warning">Live Context</span>
          </div>

          <div className="dashboard-stack">
            {linkedFaults.map((fault, index) => (
              <article key={fault.id} className="dashboard-fault-list-card">
                <div className="panel-head">
                  <div>
                    <h3>{fault.title}</h3>
                    <p>{fault.locationText}</p>
                  </div>
                  <span className={`status-chip status-chip-${getAssetTone(index === 0 ? "transformer" : "pole")}`}>{fault.priority}</span>
                </div>
                <div className="meta-row">
                  <span className="tag">{fault.category}</span>
                  <div className="tag tag-user-badge">
                    <UserBadge name={fault.assignedAdminName} currentUser={currentUser} compact />
                  </div>
                  <span className="tag">{fault.status}</span>
                </div>
              </article>
            ))}
          </div>
        </article>
      </section>
    </>
  );
}

