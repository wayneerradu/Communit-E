import { NextResponse } from "next/server";
import { createProject, listProjects } from "@/lib/workflows";

export async function GET() {
  return NextResponse.json({ items: listProjects() });
}

export async function POST(request: Request) {
  const payload = await request.json();
  const item = createProject(payload);
  return NextResponse.json({ item }, { status: 201 });
}
