import { getSessionUser } from "@/lib/auth";
import { faults } from "@/lib/demo-data";
import { InfrastructureConsole } from "@/components/infrastructure/infrastructure-console";
import { getInfrastructureData } from "@/lib/hub-data";

export default async function InfrastructurePage() {
  const { assets } = getInfrastructureData();
  const currentUser = await getSessionUser();

  return <InfrastructureConsole initialAssets={assets} faults={faults} currentUser={currentUser} />;
}
