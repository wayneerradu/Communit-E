import { getSessionUser } from "@/lib/auth";
import { ProjectsConsole } from "@/components/projects/projects-console";
import { getProjectsData } from "@/lib/hub-data";

export default async function ProjectsPage({
  searchParams
}: {
  searchParams: Promise<{ focus?: string; queue?: string; action?: string; context?: string }>;
}) {
  const { projects, parkingLotIdeas } = getProjectsData();
  const currentUser = await getSessionUser();
  const { focus, queue, action, context } = await searchParams;

  return (
    <ProjectsConsole
      initialProjects={projects}
      parkingLotIdeas={parkingLotIdeas}
      currentUser={currentUser}
      focusProjectId={focus}
      focusQueue={queue}
      focusAction={action}
      contextMessage={context}
    />
  );
}
