import { getHelpData } from "@/lib/hub-data";

export default async function HelpPage({
  searchParams
}: {
  searchParams: Promise<{ category?: string }>;
}) {
  const { category } = await searchParams;
  const { articles } = getHelpData(category);

  return (
    <>
      <header className="page-header">
        <div>
          <h1>Help Center</h1>
          <p>Deep-linked guidance for the current hub, preserved from the AppSheet design.</p>
        </div>
      </header>

      <section className="surface-panel">
        <div className="section-header">
          <div>
            <h2>{category ? `${category} help` : "All help articles"}</h2>
            <p>Filtered by hub when launched from the contextual help button.</p>
          </div>
        </div>
        <div className="panel-list">
          {articles.map((article) => (
            <article key={article.id} className="panel-card">
              <div className="panel-head">
                <h3>{article.topic}</h3>
                <span className="status-chip status-chip-default">{article.category}</span>
              </div>
              <p>{article.instructions}</p>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}
