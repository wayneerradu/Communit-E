﻿import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CommUNIT-E",
  description: "Community operations platform for residents, admins, and PRO teams."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

